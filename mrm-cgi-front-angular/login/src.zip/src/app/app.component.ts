import { Component } from '@angular/core';

@Component({
    selector: 'application',
    templateUrl: './app.component.html'
})
 
export class AppComponent {
	constructor() {

    }
}
